#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <signal.h>
#include <string.h>
/*自定义socket api*/
#include "src/include/socket_api.h"

int main(int argc,char *argv[]){
	pid_t pid;
	int tcp_server_fd,tcp_client_fd;
	char str[64],buf[64];
	int read_len;

	if((tcp_server_fd = tcp_init(argv[1],atoi(argv[2]),5)) < 0){
		return -1;
	}
	
	tcp_client_fd = tcp_build(tcp_server_fd);
	
	pid = fork();
	if(pid == -1){
		printf("fork failed\n");
		return 1;
	}
	else if(pid){ //当前进程（父进程）输入直接发送信息
		while(1){
			memset(str,0,sizeof(str));
			scanf("%s",str);
			fflush(stdin);
			if(strncmp(str,"exit",4) == 0){//输入exit退出
				kill(pid,9);
				break;
			}
			write(tcp_client_fd,str,strlen(str));
		}
	}
	else{ //子进程，接收信息返回信息
		while(1){
			memset(buf, 0, sizeof(buf));
			read_len = read(tcp_client_fd, buf, sizeof(buf));
			if(read_len){
				printf("socket data is %s!\n",buf);//至少加\n，否则有可能打印不出来
				memset(str,0,sizeof(str));
				sprintf(str,"RE:%s",buf);
				write(tcp_client_fd,str,strlen(str));
			}
		}
	}
	
	close(tcp_client_fd);
	close(tcp_server_fd);

	return 0;
}