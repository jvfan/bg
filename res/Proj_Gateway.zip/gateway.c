#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
//进程间通信：共享内存
#include <sys/shm.h> 
/*自定义串口 api*/
#include "src/include/uart_api.h"
/*自定义socket api*/
#include "src/include/socket_api.h"

int main(int argc,char *argv[]){
	pid_t pid,pid_sub;
	
	//串口配置
	char *uart3 = "/dev/ttySAC3";
	int uart_fd;
	if((uart_fd = open(uart3, O_RDWR|O_NOCTTY|O_NDELAY))<0){
		printf("open %s is failed",uart3);
		return -1;
	}
	set_opt(uart_fd, 115200, 8, 'N', 1);
	//UDP先收端配置
	int udp_fd;
	struct sockaddr_in servaddr,src_addr,*share;//src_addr记录来源地址，对应share共享内存
	if((udp_fd = udp_init_firstrecv(servaddr,"0.0.0.0",55006)) < 0){
		return -1;
	}
	//TCP客户机配置
	int tcp_fd;
	if((tcp_fd = tcp_request(argv[1],atoi(argv[2]))) < 0){
		return -1;
	}
	
	//创建共享内存
	int shmid = shmget((key_t)1234, sizeof(struct sockaddr_in), 0666|IPC_CREAT);  
    if(shmid == -1){  
        perror("shmget");
		return -1; 
    }
	//指向共享内存地址空间  
    share = shmat(shmid, 0, 0);
	
	char uart_buff[1024],udp_buff[1024],tcp_buff[1024];
	int read_len;
	//三进程处理
	pid = fork();
	if(pid == -1){
		perror("fork");
		return -1;
	}
	else if(pid){ //进程0:转发串口和UDP数据到TCP服务器
		pid_sub = fork();
		if(pid_sub == -1){
			perror("fork");
			return -1;
		}
		else if(pid_sub){ //进程0.1 转发串口数据到TCP服务器
			while(1){
				//注意因为uart_fd有O_NDELAY属性，所以read不阻塞
				memset(uart_buff, 0, sizeof(uart_buff));
				read_len = read(uart_fd, uart_buff, sizeof(uart_buff));
				if(read_len){
					printf("len is %d!\n",read_len);
					read_len = 0;
					if(strncmp(uart_buff,"exit",4) == 0){//输入exit退出
						kill(pid,9);
						kill(pid_sub,9);
						break;
					}
					memset(tcp_buff,0,sizeof(tcp_buff));
					sprintf(tcp_buff,"sci:%s",uart_buff);
					write(tcp_fd, tcp_buff, strlen(tcp_buff));
				}
				usleep(10000);//无阻塞属性的循环需要延时
			}
		}
		else{ //进程0.2 转发UDP数据到TCP服务器
			while(1){
				memset(udp_buff, 0, sizeof(udp_buff));
				read_len = udp_recv(udp_fd,udp_buff,sizeof(udp_buff),&src_addr);//接收udp信息
				if(read_len){
					memcpy(share, &src_addr, sizeof(src_addr));//记录来源信息到共享内存
					if(strncmp(udp_buff,"exit",4) == 0){//输入exit退出
						kill(pid,9);
						kill(getppid(),9);
						break;
					}
					memset(tcp_buff,0,sizeof(tcp_buff));
					sprintf(tcp_buff,"udp:%s",udp_buff);
					write(tcp_fd, tcp_buff, strlen(tcp_buff));
				}
			}
		}
	}
	else{ //进程1，转发TCP服务器的数据到串口或UDP
		while(1){
			memset(tcp_buff, 0, sizeof(tcp_buff));
			read_len = read(tcp_fd, tcp_buff, sizeof(tcp_buff));
			if(read_len){
				if(strncmp(tcp_buff,"RE:udp:",7) == 0){
					memset(udp_buff,0,sizeof(udp_buff));
					memcpy(udp_buff, tcp_buff, strlen(tcp_buff));
					udp_send(udp_fd,udp_buff,share);
				}
				else{//默认转发串口
					memset(uart_buff,0,sizeof(uart_buff));
					memcpy(uart_buff,tcp_buff,strlen(tcp_buff));
					write(uart_fd, uart_buff, strlen(uart_buff));
				}
			}
		}
	}
	
	close(uart_fd);
	close(udp_fd);
	close(tcp_fd);
	
	//把共享内存从当前进程中分离  
    if(shmdt(share) == -1)  
    {  
        fprintf(stderr, "shmdt failed\n");  
        return -1; 
    }
    //删除共享内存  
    if(shmctl(shmid, IPC_RMID, 0) == -1)  
    {  
        fprintf(stderr, "shmctl(IPC_RMID) failed\n");  
        return -1;  
    }

	return 0;
}